Last Release : 19/11/19

Author : R�mi Dayon

Description :
Ramboolean is a versus game. You control a char and you have to shoot at your opponent to beat him.
Destroy the field during your intense battle.

Controls :
Use up and down arrow to adjuste your fire angle.
Use space to fire. The power of the shoot depend on how long you press the space key. 
Press I key to open an inventory. an press it again to close it.
You can change your weapon in the inventory. Each weapon has it own sensitivity to wind and is own blow up power.

Known issues : No known issues.